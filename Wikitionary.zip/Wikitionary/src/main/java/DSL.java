import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class DSL {
	private WebDriver driver;

	
	public DSL(WebDriver driver) {
		this.driver = driver;
	}
	public void submit() {
	driver.findElement(By.name("go")).click();

	}
	


	public void write(String id, String text) {
		driver.findElement(By.name(id)).sendKeys(text);;
		 
	 }
	
	public boolean findText(String value) {
		if(driver.findElement(By.tagName("body")).getText().contains(value)) {
			return true;
		}
		return false;
	}

}
