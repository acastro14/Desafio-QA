import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MesaTest {
	private WebDriver driver;
	private  DSL dsl;
	
	@Before
	public void start() {
		System.setProperty("webdriver.gecko.driver",System.getProperty("user.dir") + "/src/main/resources/geckodriver.exe");
		driver = new FirefoxDriver();
		driver.get("https://en.wiktionary.org/");
		dsl= new DSL(driver);
	}
	
	@After
	public void terminate (){
		driver.quit();
	}
	@Test
	public void AppleTest() {
		dsl.write("search","Apple");
		dsl.submit();
		String value = "'A common, round fruit produced by the tree Malus domestica, cultivated in temperate climates.";
		Assert.assertTrue(dsl.findText(value));			
		
	}
	
	@Test
	public void PearTest() {
		dsl.write("search","Pear");
		dsl.submit();
		String value = "An edible fruit produced by the pear tree, similar to an apple but elongated towards the stem.";
		Assert.assertTrue(dsl.findText(value));		
	}
}
